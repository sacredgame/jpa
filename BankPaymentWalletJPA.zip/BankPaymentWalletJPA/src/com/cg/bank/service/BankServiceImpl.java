package com.cg.bank.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.transaction.Transaction;

import com.cg.bank.dao.IBankDao;
import com.cg.bank.dao.BankDaoImpl;
import com.cg.bank.dto.Customer;
import com.cg.bank.dto.Transactions;
import com.cg.bank.exception.BankException;


public class BankServiceImpl implements IBankService{
	IBankDao dao;
	
	public BankServiceImpl() throws BankException {
		dao = new BankDaoImpl();
	}
	
	@Override
	//adding customer account to database calls dao method createAccount(Customer customer)
	public void createAccount(Customer customer) 
	{
		dao.createAccount(customer);	
	}
	
	
	@Override
	//calls dao method deposit(String mobileNo, double amount)
	public void deposit(String mobileNo, double amount) {
		dao.deposit(mobileNo, amount);
	}
	
	
	@Override
	//calls dao method withdraw(String mobileNo, double amount)
	public void withdraw(String mobileNo, double amount) {
		dao.withdraw(mobileNo, amount);
	}
	
	
	@Override
	//calls dao method checkBalance(String mobileNo)
	public double checkBalance(String mobileNo) {
		return dao.checkBalance(mobileNo);
	}
	
	
	@Override
	//calls dao method fundTransfer(String sender, String reciever, double amount)
	public void fundTransfer(String sender, String reciever, double amount) {
		dao.fundTransfer(sender, reciever, amount);
		
	}
	
	
	//validates the Customer Name
	public boolean validateName(String name) throws BankException {		//Checking for valid name
		if(name == null)
			throw new BankException("Null value found");
		Pattern p = Pattern.compile("[A-Z]{1}[a-z]{2,10}");
		Matcher m = p.matcher(name); 
		if(!m.matches())
			System.out.println("Name invalid! Name should start with a capital letter and contain only alphabets");
		return m.matches();	
	}
	
	
	@Override
	//validates the Customer Age
	public boolean validateAge(float age)  throws BankException {		//Checking for valid age
		try{
			if(age == 0)
				System.out.println("Age cannot be  null");
			else if(age >100)
				System.out.println("Age cannot be  greater than 100");
			else if(age < 0)
				System.out.println("Age cannot be a negative number");
			else if(age <=17)
				System.out.println("Minimum age to open account is 18");
			else if(age >17)
				return true;
	} catch (Exception e) {
		e.printStackTrace();
	}
		return false;
	}

	
	@Override
	//validates the Customer's Mobile No.
	public boolean validateMoileNo(String mobileNo) throws BankException{		//Checking for valid mobile number
		try{
			if(mobileNo == null)
				throw new BankException("Null value found");
			Pattern p = Pattern.compile("[6789][0-9]{9}");
			Matcher m = p.matcher(mobileNo);
			if(!m.matches())
				System.out.println("Mobile Number Invalid! Enter a valid Indian number (6-9) of 10 digits");
			return m.matches();
	} catch (Exception e) {
		e.printStackTrace();
	}
		return false;
	}
	
	
	@Override
	//validates the Amount.
	public boolean validateAmount(double amount) throws BankException {			//Checking for valid transaction amount
		String am = String.valueOf(amount);
		if(amount == 0){
			System.out.println("Null value found! Amount cannot be zero");
			return false;
		}
		else if(!am.matches("\\d{3,9}\\.\\d{0,4}")){
			System.out.println("Invalid Amount! Minimum transaction amount is Rs.100");
			return false;
		}
		else{
			return (am.matches("\\d{3,9}\\.\\d{0,4}"));
		}
		
	}

	@Override
	public boolean validateAccount(String mobileNo) {		
		return dao.validateAccount(mobileNo);	
	}

	@Override
	public List<Transactions> getTransList(String mobileNo) {
		return dao.getTransList(mobileNo);
	}

}
