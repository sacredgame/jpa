package com.cg.bank.test;
import org.junit.Assert;
import org.junit.Test;

import com.cg.bank.exception.BankException;
import com.cg.bank.service.IBankService;
import com.cg.bank.service.BankServiceImpl;
public class TestClass {
	//TestClass cases for name
		@Test(expected=BankException.class)
	    public void test_ValidateName_null() throws BankException{
	        IBankService service=new BankServiceImpl();
	        service.validateName(null);
	    }
	    
	    @Test
	    public void test_validateName_v1() throws BankException{
	    
	        String name="Dinesh234";
	        IBankService service=new BankServiceImpl();
	        boolean result= service.validateName(name);
	        Assert.assertEquals(false,result);
	    }
	    @Test
	    public void validateName2() throws BankException{
	    
	        String name="Dinu";
	        IBankService service=new BankServiceImpl();
	        boolean result= service.validateName(name);
	        Assert.assertEquals(true,result);
	    }
	    @Test
	    public void validateName3() throws BankException{
	    
	        String name="dinesh";
	        IBankService service=new BankServiceImpl();
	        boolean result= service.validateName(name);
	        Assert.assertEquals(false,result);
	    }
	    
	    //TestClass cases for Mobile number
	    @Test(expected=BankException.class)
	    public void validateMobNum_null() throws BankException{
	        IBankService service=new BankServiceImpl();
	        service.validateMoileNo(null);
	    }
	    
	    @Test
	    public void validateMobNum1() throws BankException{
	        String mobNo="KBC067543287";
	        IBankService service=new BankServiceImpl();
	        boolean result= service.validateMoileNo(mobNo);
	        Assert.assertEquals(false,result);
	    }
	    @Test
	    public void validateMobNum2() throws BankException{
	    
	        String mobNo="9867988985";
	        IBankService service=new BankServiceImpl();
	        boolean result= service.validateMoileNo(mobNo);
	        Assert.assertEquals(true,result);
	    }
	    @Test
	    public void validateMobNo3() throws BankException{
	    
	        String mobNo="890754";
	        IBankService service=new BankServiceImpl();
	        boolean result= service.validateMoileNo(mobNo);
	        Assert.assertEquals(false,result);
	    }

}
